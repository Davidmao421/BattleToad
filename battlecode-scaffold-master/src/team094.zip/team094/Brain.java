package team094;

import battlecode.common.RobotController;

public interface Brain {

	public void run(RobotController rc);
	
	
}
